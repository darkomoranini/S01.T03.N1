
public class Jugador {

	String nombre;
	int puntuacion;
	
	public Jugador(String nombre) {
		this.nombre=nombre;
		puntuacion=0;
	}
	public int getPuntuacion() {
		return puntuacion;
	}
	public void setPuntuacion(int puntuacion) {
		this.puntuacion = puntuacion;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int sumaPuntos() {
		return puntuacion+=1;
	}
}
