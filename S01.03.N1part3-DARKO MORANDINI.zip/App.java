
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
public class App {

	public static void main(String[] args) {		
		
		ArrayList<Jugador>listaJugadores=new ArrayList<Jugador>();
		
		Map<String, String> map = new HashMap<>();
		
		try {
			BufferedReader input=new BufferedReader(new FileReader("/Users/darkomorandini/Desktop/Countries.txt"));
			String line = input.readLine();
			
			while(line.length()!=0) {
				String[] parts = line.split(" ");
				String key=parts[0];
				String value=parts[1];
				map.put(key, value); 
				line=input.readLine();				
			}
			input.close();
		} catch (IOException e) {
			System.out.println("No se ha encontrado el archivo");
		}
		
		creaJugador(pideString("Introduce tu nombre"), listaJugadores);   
		
		Set<String> keySet = map.keySet();                
		String[] keyArray = keySet.toArray(new String[0]);
		Random random = new Random();
		String randomKey;
		
		for(int i=0; i<=10; i++) {
			
			randomKey = keyArray[random.nextInt(keyArray.length)];
			System.out.println("Pais: " + randomKey);
			
				if(pideString("Introduce capital").equalsIgnoreCase(randomKey)) {
					System.out.println("Has acertado..tu puntuacion es: "+listaJugadores.get(i).sumaPuntos());		
				}else {
					System.out.println("No has acertado..tu puntuacion es: "+listaJugadores.get(i).getPuntuacion());						
				}
		}	
	}
	
	public static void creaJugador(String nombre, ArrayList<Jugador>listaJugadores) {
		Jugador jugador=new Jugador(nombre);
		listaJugadores.add(jugador);
	}
	public static String pideString(String mensaje) {
		Scanner input = new Scanner(System.in);
		System.out.println(mensaje);
		String texto = input.nextLine();
		input.close();
		return texto;  
	}
	
}
