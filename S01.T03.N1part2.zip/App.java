import java.util.*;
public class App {

	public static void main(String[] args) {
		
		ArrayList<Integer> listaNumeros= new ArrayList<Integer>();
		listaNumeros.add(1);
		listaNumeros.add(2);
		listaNumeros.add(3);
		listaNumeros.add(4);
		listaNumeros.add(5);
		
		for(int i=0; i<listaNumeros.size(); i++) {
			System.out.println(listaNumeros.get(i));	
		}
		ArrayList<Integer> listaNumeros2= new ArrayList<Integer>();
		for(int i=listaNumeros.size()-1; i>=0; i--) {
			listaNumeros2.add(listaNumeros.get(i));
		}
		
		for(int i=0; i<listaNumeros2.size(); i++) {
		System.out.println(listaNumeros2.get(i));	
		}
	
		Iterator<Integer>iterator=listaNumeros2.listIterator(listaNumeros.size());
		while(((ListIterator<Integer>) iterator).hasPrevious())
			  System.out.println(((ListIterator<Integer>) iterator).previous());
	}
}
