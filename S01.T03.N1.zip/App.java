import java.util.*;

public class App {

	public static void main(String[] args) {
		
		ArrayList<Month>listaMeses=new ArrayList<Month>();
		
		Month month1=new Month("enero");
		listaMeses.add(month1);
		Month month2=new Month("febrero");
		listaMeses.add(month2);
		Month month3=new Month("marzo");
		listaMeses.add(month3);
		Month month4=new Month("abril");
		listaMeses.add(month4);
		Month month5=new Month("mayo");
		listaMeses.add(month5);
		Month month6=new Month("junio");
		listaMeses.add(month6);
		Month month7=new Month("julio");
		listaMeses.add(month7);
		Month month8=new Month("agosto");
		Month month9=new Month("septiembre");
		listaMeses.add(month9);
		Month month10=new Month("octubre");
		listaMeses.add(month10);
		Month month11=new Month("noviembre");
		listaMeses.add(month11);
		Month month12=new Month("diciembre");
		listaMeses.add(month12);
		//listaMeses.add(7, month8);
		
		for(int i=0; i<listaMeses.size(); i++) {
				System.out.println(listaMeses.get(i).getName());
		}		
			
		Set<Month>hashMeses=new HashSet<Month>();
		hashMeses.add(month1);
		hashMeses.add(month2);
		hashMeses.add(month3);
		hashMeses.add(month4);
		hashMeses.add(month5);
		hashMeses.add(month6);
		hashMeses.add(month7);
		hashMeses.add(month8);
		hashMeses.add(month9);
		hashMeses.add(month10);
		hashMeses.add(month11);
		hashMeses.add(month12);
		//hashMeses.add(month1);
			
		Iterator<Month>itirator=listaMeses.iterator();
			while(itirator.hasNext()) {
				System.out.println(itirator.next().getName());
			}				
	}
}
